//
// Created by Eunhee Kim on February 24, 2020.
//

#include <climits>
#include <cstdlib>
#include <iostream>

#include "skiplist.h"
#include <cassert>

using namespace std;

// the output operator that will print out all the values from each level
// in the skiplist
ostream& operator<<(ostream& out, const SkipList& skipList) {
    for (int i = skipList.depth - 1; i >= 0; i--) {
        out << "Level: " << i << " -- ";
        SkipList::SNode* s = skipList.frontGuards[i];
        while (s != nullptr) {
            out << s->data << ", ";
            s = s->next;
        }
        out << endl;
    }
    return out;
}

// Constructor for SNode: set the data, set all other pointers to nullptr
SkipList::SNode::SNode(int data)
    : data{data}, next{nullptr}, prev{nullptr}, upLevel{nullptr},
      downLevel{nullptr} {}

// Constructor for SkipList: Dynamically allocate frontGuards and rearGuards
// arrays, create the special SNode* objects as guards, tie all the SNode
// objects together (both prev-next and up-down)
SkipList::SkipList(int depth) {
    // setting the depth from the input of the constructor
    this->depth = depth;
    // array of frontGuards have an amount equal to depth
    frontGuards = new SNode*[depth];
    // array of rearGuards have an amount equal to depth
    rearGuards = new SNode*[depth];
    // filling up the the levels with values that include the frontGuards
    // to equal the INT_MIN, and the rearGuards to equal the INT_MAX
    for (int i = 0; i < depth; i++) {
        frontGuards[i] = new SNode(INT_MIN);
        rearGuards[i] = new SNode(INT_MAX);
        // the frontGuards and rearGuards will be pointing at each other
        // and anything before the front and after the rear will be a nullptr
        frontGuards[i]->next = rearGuards[i];
        frontGuards[i]->prev = nullptr;
        rearGuards[i]->prev = frontGuards[i];
        rearGuards[i]->next = nullptr;
        // if the level is in 0, there will be no downlevels
        if (i == 0) {
            frontGuards[i]->downLevel = nullptr;
            rearGuards[i]->downLevel = nullptr;
        } else {
            // else, each level will point down to the level below
            frontGuards[i]->downLevel = frontGuards[i - 1];
            rearGuards[i]->downLevel = rearGuards[i - 1];
        }
        if (i < depth - 1) {
            // while you are not on the most top level, the front Guards will
            // always point to its upper level to be the frontGuards above it
            frontGuards[i]->upLevel = frontGuards[i + 1];
            rearGuards[i]->upLevel = rearGuards[i + 1];
        }
    }
}

bool SkipList::alsoHigher() const { return rand() % 2 == 1; }

// SkipList::Add: return false if the given value is already in level-0
bool SkipList::add(int data) {
    // Set SNode*, such nextNode to be frontGuards[0]->next
    SNode* nextNode = frontGuards[0]->next;
    // As long as nextNode->next is not null and
    // nextNode->data < data, keep moving nextNode to the right
    while (nextNode->next != nullptr && nextNode->data < data) {
        nextNode = nextNode->next;
        // If nextNode->data == data, return false
        // stating duplicates are not allowed
        if (nextNode->data == data) {
            cout << "duplicates are not allowed";
            return false;
        }
    }
    // create a new SNode called newNode, put the data in it
    SNode* newNode = new SNode(data);
    // call addBefore(newNode, nextNode);
    // to connect all the pointers together
    addBefore(newNode, nextNode);
    int i = 1;
    // toss a coin to check if it should be inserted at higher level
    while (alsoHigher() && i < depth) {
        // Create another node to be inserted at the higher level, newUpper
        SNode* newUpper = new SNode(data);
        // Connect newNode and newUpper (up-down
        newNode->upLevel = newUpper;
        newUpper->downLevel = newNode;
        //
        nextNode = frontGuards[i];
        while (nextNode != nullptr && nextNode->data < data) {
            nextNode = nextNode->next;
        }
        // Call addBefore to insert newUpper
        // to come before the node you just got to
        addBefore(newUpper, nextNode);
        // Set newNode to be newUpper
        newNode = newUpper;
        i++;
    }
    return true;
}

void SkipList::addBefore(SNode* newNode, SNode* nextNode) {

    // the newNode's next node to be nextNode
    newNode->next = nextNode;
    // the newNode's previous node to be the nextNode's previous
    newNode->prev = nextNode->prev;
    // the nextNode's previous node to be the newNode, because we are adding
    // the newNode before the nextNode
    nextNode->prev = newNode;
    if (newNode->prev != nullptr) {
        newNode->prev->next = newNode;
    }
}

SkipList::~SkipList() {
    // need to delete individual nodes
    // creating a node to point to the current node to delete,
    // and another node to place a temporary node in
    SNode* current;
    SNode* temp;
    // looping over the each level
    for (int i = 0; i < depth; i++) {
        // current will start from the frontGuards of the bottom level
        current = frontGuards[i];
        // while the current is not null, the temporary will hold the current
        // value and the current will move over to its next node so that the temp
        // will be deleted
        while (current != nullptr) {
            temp = current;
            current = current->next;
            delete temp;
        }
    }
    // deleting both arrays of the frontGuards and rearGuards
    delete[] frontGuards;
    delete[] rearGuards;
}

bool SkipList::remove(int data) {
    //for loop for going through each of the levels, starting from
    //top to bottom
    for (int i = depth - 1; i >= 0; i--) {
        //creating a node to traverse through from the top level frontGuards
        SNode* current = frontGuards[i];
        //while the current is not null and the current is greater or equal 
        //to the data trying to remove, it will delete the node when it is
        //found and return true, or it will continue searching to the next node
        while (current != nullptr && current->data <= data) {
            if (current->data == data) {
                current->prev->next = current->next;
                current->next->prev = current->prev;
                delete current;
                return true;
            } else {
                current = current->next;
            }
        }
    }
    return false;
}

// SkipList::Contains: return true if the given value is in SkipList
bool SkipList::contains(int data) {
    // Start at top - left, highest level frontGuards[depth - 1],
    // let's call this node current
    SNode* current = frontGuards[depth - 1];
    // As long as current is not nullptr
    while (current != nullptr) {
        // Keep moving right as long as the
        // current->next->data is less than value
        while (current->next != nullptr && current->next->data < data) {
            current = current->next;
        }

        // If current->next->data is equal to value,
        // return true
        if (current->next->data == data) {
            return true;
        }
        // else
        // set current to be the node down one level from current node
        else {
            current = current->downLevel;
        }
    }
    // If current is nullptr, the item is not in SkipList
    return false;
}