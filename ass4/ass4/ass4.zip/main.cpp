//
// Created by Eunhee Kim on February 24, 2020.
//

#include "skiplist.h"
#include <iostream>
#include <sstream>
#include <random>

using namespace std;

int totalPassed = 0;
int totalTests = 0;

template <typename T> string isOK(const T& got, const T& expected) {
    ++totalTests;
    if (got == expected) {
        ++totalPassed;
        return "OK: ";
    }
    else {
        cout << "    Got   " << got << "\n expected " << expected << endl;
        return "ERR: ";
    }
}

void test02() {
    SkipList skipList(3);
    stringstream ss;
    ss << skipList;
    cout << isOK(ss.str(), string("Level: 2 -- -2147483648, 2147483647, \n"
        "Level: 1 -- -2147483648, 2147483647, \n"
        "Level: 0 -- -2147483648, 2147483647, \n"))
        .c_str()
        << "Empty SkipList of Depth=3" << endl;
    srand(100);
    skipList.add(10);
    skipList.add(30);
    skipList.add(5);
    skipList.add(25);
    ss.str("");
    ss << skipList;
    cout << isOK(ss.str(),
        string(
            "Level: 2 -- -2147483648, 25, 30, 2147483647, \n"
            "Level: 1 -- -2147483648, 25, 30, 2147483647, \n"
            "Level: 0 -- -2147483648, 5, 10, 25, 30, 2147483647, \n"))
        << "SkipList of Depth=3 with 10, 30, 5, 25" << endl;
    cout << isOK(skipList.contains(10), true) << "Contains 10" << endl;
    cout << isOK(skipList.contains(30), true) << "Contains 30" << endl;
    cout << isOK(skipList.contains(71), false) << "Does not contain 71" << endl;
}

void test01() {
    SkipList skipList;
    stringstream ss;
    ss << skipList;
    cout << isOK(ss.str(), string("Level: 0 -- -2147483648, 2147483647, \n"))
        << "Empty SkipList" << endl;
    skipList.add(10);
    skipList.add(30);
    skipList.add(5);
    skipList.add(25);
    ss.str("");
    ss << skipList;
    cout << isOK(ss.str(),
        string(
            "Level: 0 -- -2147483648, 5, 10, 25, 30, 2147483647, \n"))
        << "Added 10, 30, 5, 25," << endl;
}

void test03() {
    SkipList skipList(5);
    stringstream ss;
    ss << skipList;
    cout << isOK(ss.str(), string(
        "Level: 4 -- -2147483648, 2147483647, \n"
        "Level: 3 -- -2147483648, 2147483647, \n"
        "Level: 2 -- -2147483648, 2147483647, \n"
        "Level: 1 -- -2147483648, 2147483647, \n"
        "Level: 0 -- -2147483648, 2147483647, \n"))
        .c_str()
        << "Empty SkipList of Depth=5" << endl;
    skipList.add(10);
    skipList.add(1);
    skipList.add(99);
    skipList.add(45);
    skipList.add(39);
    skipList.add(150);
    skipList.add(34);
    skipList.add(74);
    skipList.add(90);
    skipList.add(200);
    skipList.add(50);
    ss.str("");
    ss << skipList;
    cout << isOK(ss.str(),
        string(
            "Level: 4 -- -2147483648, 200, 2147483647, \n"
            "Level: 3 -- -2147483648, 200, 2147483647, \n"
            "Level: 2 -- -2147483648, 10, 99, 200, 2147483647, \n"
            "Level: 1 -- -2147483648, 10, 34, 45, 74, 90, 99, 200, 2147483647, \n"
            "Level: 0 -- -2147483648, 1, 10, 34, 39, 45, 50, 74, 90, 99, 150, 200, 2147483647, \n"))
        << "SkipList of Depth=5 with 10, 1, 99, 45, 39, 150, 34, 74, 90, 200, 50" << endl;
    cout << isOK(skipList.contains(200), true) << "Contains 200" << endl;
    cout << isOK(skipList.contains(1), true) << "Contains 1" << endl;
    cout << isOK(skipList.contains(89), false) << "Does not contain 89" << endl;
    cout << isOK(skipList.remove(50), true) << "Removing 50" << endl;
    cout << isOK(skipList.remove(81), false) << "Can't remove 81" << endl;
}

void test04() {
    SkipList skipList(10);
    stringstream ss;
    ss << skipList;
    cout << isOK(ss.str(), string(
        "Level: 9 -- -2147483648, 2147483647, \n"
        "Level: 8 -- -2147483648, 2147483647, \n"
        "Level: 7 -- -2147483648, 2147483647, \n"
        "Level: 6 -- -2147483648, 2147483647, \n"
        "Level: 5 -- -2147483648, 2147483647, \n"
        "Level: 4 -- -2147483648, 2147483647, \n"
        "Level: 3 -- -2147483648, 2147483647, \n"
        "Level: 2 -- -2147483648, 2147483647, \n"
        "Level: 1 -- -2147483648, 2147483647, \n"
        "Level: 0 -- -2147483648, 2147483647, \n"))
        .c_str()
        << "Empty SkipList of Depth=10" << endl;
    skipList.add(99);
    skipList.add(44);
    skipList.add(11);
    skipList.add(444);
    skipList.add(22);
    skipList.add(66);
    skipList.add(7777);
    skipList.add(55);
    skipList.add(88);
    skipList.add(1000);
    skipList.add(33);
    skipList.add(222);
    skipList.add(777777);
    skipList.add(333333);
    skipList.add(3);
    skipList.add(6);
    ss.str("");
    ss << skipList;
    cout << isOK(ss.str(),
        string(
            "Level: 9 -- -2147483648, 2147483647, \n"
            "Level: 8 -- -2147483648, 2147483647, \n"
            "Level: 7 -- -2147483648, 2147483647, \n"
            "Level: 6 -- -2147483648, 2147483647, \n"
            "Level: 5 -- -2147483648, 2147483647, \n"
            "Level: 4 -- -2147483648, 2147483647, \n"
            "Level: 3 -- -2147483648, 2147483647, \n"
            "Level: 2 -- -2147483648, 44, 66, 333333, 2147483647, \n"
            "Level: 1 -- -2147483648, 3, 6, 11, 44, 66, 88, 7777, 333333, 777777, 2147483647, \n"
            "Level: 0 -- -2147483648, 3, 6, 11, 22, 33, 44, 55, 66, 88, 99, 222, 444, 1000, 7777, 333333, 777777, 2147483647, \n"))
        << "SkipList of Depth=10 with 99, 44, 11, 444, 22, 66, 7777, 55, 88, 1000, 33, 222, 777777, 333333, 3, 6" << endl;
    cout << isOK(skipList.remove(3), true) << "Removing 3" << endl;
    cout << isOK(skipList.remove(7777), true) << "Removing 7777" << endl;
    cout << isOK(skipList.remove(90), false) << "Can't remove 90" << endl;
    cout << isOK(skipList.remove(11), true) << "Removing 11" << endl;
}

int main() {
    cout << "Because of the random nature of SkipList, "
        << "the skip list levels may not match" << endl;
    // Set the random seed for easy debugging
    // NOLINTNEXTLINE
    srand(424242);
    test01();
    test02();
    test03();
    test04();
    cout << "Passed: " << totalPassed << "/" << totalTests << endl;
    return 0;
}