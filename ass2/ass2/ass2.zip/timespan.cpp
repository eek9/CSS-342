//
// Created by Eunhee Kim on January 20, 2020.
//

#include "timespan.h"

//Constructor that sets up the hours, minutes, and seconds of the time
TimeSpan::TimeSpan(double h, double m, double s) {
    hours = h;
    min = m;
    sec = s;
}

//copy constructor
TimeSpan::TimeSpan(const TimeSpan &timespan) {
    hours = timespan.hours;
    min = timespan.min;
    sec = timespan.sec;
}

//output operator that prints out the time information
ostream& operator<<(ostream& output, const TimeSpan& timespan) {
    TimeSpan ts;
    ts.reduce(timespan.totalS);
    output << "Hours: " << ts.hours << "Minutes: " << ts.min << "Seconds: " << ts.sec;
    return output;
}

//addition operator for time
TimeSpan TimeSpan::operator+(const TimeSpan& timespan) const {
    TimeSpan ts(timespan.hours+hours, timespan.min+min, timespan.sec+sec);

    //I had many problems in trying to fix this compiling error because it was not letting me return the TimeSpan object.
    //It kept telling me that I have not made a suitable copy constructor but I thought that I have already done so
    return TimeSpan(ts);
}

//subtracting operator for time
TimeSpan TimeSpan::operator-(const TimeSpan& timespan) const {
    TimeSpan ts;

    ts.hours = hours - timespan.hours;
    ts.min = min - timespan.min;
    ts.sec = sec - timespan.sec;
    return TimeSpan(ts.hours, ts.min, ts.sec);
}

//multiplication operator by integers for time
TimeSpan TimeSpan::operator*(int number) {
    TimeSpan ts;

    ts.hours = hours * number;
    ts.min = min * number;
    ts.sec = sec * number;
    return ts;
}

//boolean method that checks the equality of two times
bool TimeSpan::operator==(const TimeSpan& timespan) const {
    return((hours == timespan.hours) && (min == timespan.min) && (sec == timespan.sec));
}

//boolean method that checks the unequality of the two times
bool TimeSpan::operator!=(const TimeSpan& timespan) const {
    return !(*this == timespan);
}

//method that adds the time to itself and another time
TimeSpan TimeSpan::operator+=(const TimeSpan& timespan) const {
    TimeSpan ts;
    ts.hours = hours + timespan.hours;
    ts.min = min + timespan.min;
    ts.sec = sec + timespan.sec;

    return ts;
}

//method that subtracts the time to itself and another time
TimeSpan TimeSpan::operator-=(const TimeSpan& timespan) const {
    TimeSpan ts;
    ts.hours = hours - timespan.hours;
    ts.min = min - timespan.min;
    ts.sec = sec - timespan.sec;

    return TimeSpan(ts);
}

//boolean method that checks if the time is less than another
bool TimeSpan::operator<(const TimeSpan& timespan) const {
    return (hours < timespan.hours) && (min < timespan.min) && (sec < timespan.sec);
}

//boolean method that checks if the time is less than or equal to another
bool TimeSpan::operator<=(const TimeSpan& timespan) const {
    return *this == timespan || *this < timespan;
}

//boolean method that checks if the time is greater than another
bool TimeSpan::operator>(const TimeSpan& timespan) const {
    return ((hours > timespan.hours) && (min > timespan.min) && (sec > timespan.sec));
}

//boolean method that checks if the time is greater or equal to another
bool TimeSpan::operator>=(const TimeSpan& timespan) const {
    return *this == timespan || *this > timespan;
}

//method that will simplify and reduce the time
TimeSpan TimeSpan::reduce(int totalSec) {
    int finalS = int(totalSec % 60);
    int m = totalSec / 60;
    int finalM = int(m % 60);
    int h = int(m / 60);

    sec = finalS;
    min = finalM;
    hours = h;
}