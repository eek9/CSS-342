#pragma once
//
// Created by Eunhee Kim on January 20, 2020.
//

#pragma once
#include <iostream>
using namespace std;

class TimeSpan {

  //output function
  friend ostream &operator<<(ostream& output, const TimeSpan& timespan);

public:

  // explicit TimeSpan(int hours = 0, int minutes = 0, int seconds = 0);
  explicit TimeSpan(double hours = 0, double minutes = 0, double seconds = 0);

  //copy constructor
  explicit TimeSpan(const TimeSpan& timespan);

  // add
  TimeSpan operator+(const TimeSpan& timespan) const;

  // subtract
  TimeSpan operator-(const TimeSpan& timespan) const;
  
  // add timespan object to itself
  TimeSpan operator+=(const TimeSpan& timespan) const;
  
  // subtract timespan object to itself
  TimeSpan operator-=(const TimeSpan& timespan) const;
  
  // check equality
  bool operator==(const TimeSpan& timespan) const;
  
  // check if not equal
  bool operator!=(const TimeSpan& timespan) const;
  
  // check if less than
  bool operator<(const TimeSpan& timespan) const;
  
  // check if less than or equal to
  bool operator<=(const TimeSpan& timespan) const;
  
  // check if greather than
  bool operator>(const TimeSpan& timespan) const;
  
  // check if greater than or equal to
  bool operator>=(const TimeSpan& timespan) const;
  
  // multiply timespan by a number
  TimeSpan operator*(int number);
  
private:
    double hours, min, sec;
    TimeSpan reduce(int totalSec);
    int totalS;
};
