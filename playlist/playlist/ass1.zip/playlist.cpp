// Playlist class demonstrating partially filled arrays
// Can add/remove songs from playlist
// find songs in playlist

#include "playlist.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

static const int MAX = 100;
std::string playlist[MAX] = {};
string playlistName;
int numberOfSongs;

// constructor with default name
Playlist::Playlist(const std::string &name) {
    playlistName = name;
    numberOfSongs = 0;
}

// destructor
// nothing on heap
Playlist::~Playlist() = default;

// true if song found in playlist
bool Playlist::isInPlaylist(const string& song) const {
    for (int i = 0; i < numberOfSongs; i++) {
        if (playlist[i] == song) {
            return true;
        }
    }
    return false;
}

//return the valid index if song is in playlist or -1 if song is not in the playlist
int Playlist::findSong(const string& song) const {
    for (int i = 0; i < numberOfSongs; i++) {
        if (playlist[i] == song) {
            return i;
        }
    }
    return -1;
}

// add a new song
// return true if successful, false if song already in playlist
bool Playlist::addSong(const string& song) {
    if (isInPlaylist(song)) {
        return false;
    }
    else {
        playlist[numberOfSongs++] = song;
        return true;
    }
}

// remove a song
// return true if successfully removed, false if song not in playlist
bool Playlist::removeSong(const string& song) {
    if (isInPlaylist(song)) {
        int idx = findSong(song);    
        playlist[idx] = playlist[numberOfSongs - 1];
        --numberOfSongs;
        return true;
    }
    return false;
}

// list all songs
void Playlist::listAllSongs() const {
    if (numberOfSongs == 0) {
        cout << "Empty Playlist" << std::endl;
    }
    else {
        for (int i = 0; i < numberOfSongs; i++) {
            cout << playlist[i] << std::endl;
        }
    }
}

// list shuffled songs with count
void Playlist::listShuffledSongs(unsigned int count) const {

    for (int i = 0; i < count; ++i) {
        int random = std::rand() % numberOfSongs + 0;
        std::cout << i + 1 << " " << playlist[random] << std::endl;
    }
}

ostream& operator<<(ostream& Out, const Playlist& playlist) {
    Out << "Playlist: " << playlist.playlistName << std::endl;

    return Out;
}
